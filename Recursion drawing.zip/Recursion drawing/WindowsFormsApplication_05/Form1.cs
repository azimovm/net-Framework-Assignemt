﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication_05
{
    public partial class Form1 : Form
    {

        Graphics g;
        Pen myPen = new Pen(Color.Black, 2);
        int x = 50; 
        int y = 10;
        int w = 200;
        int h = 200;

        public Form1()
        {
            InitializeComponent();
            g = panel1.CreateGraphics();
        }
        
        public void DrawCircles(int fx, int fy, int fw, int fh, int depth)
        {
            g.DrawEllipse(myPen, new Rectangle(fx, fy, fh, fw));
            if (depth > 1)
                DrawCircles(fx + 5, fy + 5, fw - 10, fh - 10, depth - 1);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int depth = int.Parse(textBox1.Text);
            if (depth >= 1 && depth <= 20)
            {
                g.Clear(Form1.DefaultBackColor);
                DrawCircles(x, y, w, h, depth);
            }
        }
    }
}
